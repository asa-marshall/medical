'use strict';

//Define the 'main' module
angular.module('recruiter.applicantFind',[]);

