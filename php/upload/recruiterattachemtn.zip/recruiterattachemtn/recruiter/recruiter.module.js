'use strict';

//Define the 'main' module
angular.module('recruiter',[
    'recruiter.applicantFind',
    'recruiter.applicantDocs'
]);

