'use strict';

//Define the 'addApplicant' module
angular.module('recruiter.siteAddApplicant', []);
